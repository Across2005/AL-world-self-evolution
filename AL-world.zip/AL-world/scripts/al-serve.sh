#!/bin/bash
# AL-world 服务启动脚本
set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
AL_WORLD_DIR="$(dirname "$SCRIPT_DIR")"

echo "========================================"
echo "  AL-world — AI Learning Art World"
echo "  版本: 2.0.0"
echo "========================================"
echo ""
echo "知识库状态:"
for kb in "hanfu-culture" "figure-drawing" "art-prompts"; do
  KB_DIR="$AL_WORLD_DIR/knowledge/$kb"
  if [ -d "$KB_DIR" ]; then
    INDEX_FILE="$KB_DIR/index.json"
    PROMPT_FILE="$KB_DIR/prompts.json"
    if [ -f "$INDEX_FILE" ]; then
      NAME=$(grep -o '"name"[^,]*' "$INDEX_FILE" | head -1 | sed 's/"name": "//;s/"//')
      echo "  ✅ $NAME"
    fi
    if [ -f "$PROMPT_FILE" ]; then
      COUNT=$(grep -c '"en":' "$PROMPT_FILE" 2>/dev/null || echo 0)
      echo "     可复用提示词模板: $COUNT 条"
    fi
  fi
done

echo ""
echo "全局索引:"
for idx in "category-map.json" "tag-index.json"; do
  IDX_PATH="$AL_WORLD_DIR/index/$idx"
  if [ -f "$IDX_PATH" ]; then
    echo "  ✅ $idx"
  fi
done

echo ""
echo "服务状态:"
echo "  Node.js 视觉桥接: $(node -e "console.log('可用 (node ' + process.version + ')')" 2>/dev/null || echo '未安装')"
echo "  Python 知识流水线: $(python --version 2>/dev/null || echo '未安装')"

echo ""
echo "使用方式:"
echo "  al-analyze.sh <图片路径> [模型]   分析单张图片"
echo "  al-batch.sh <图片目录> [模型]    批量分析"
echo "  vision-bridge.js --image <路径>   直接调用视觉模型"