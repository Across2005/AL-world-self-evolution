#!/bin/bash
# AL-world 批量分析脚本
# 用法: ./al-batch.sh <图片目录> [模型]

set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
AL_WORLD_DIR="$(dirname "$SCRIPT_DIR")"
IMG_DIR="${1:?错误: 请提供图片目录}"
MODEL="${2:-kimi}"
LIMIT="${3:-10}"

if [ ! -d "$IMG_DIR" ]; then
  echo "错误: 目录不存在: $IMG_DIR"
  exit 1
fi

echo "[AL-world] 批量分析: $IMG_DIR"
echo "[AL-world] 模型: $MODEL, 上限: $LIMIT 张"

count=0
for img in "$IMG_DIR"/*.{jpg,jpeg,png,webp,gif} 2>/dev/null; do
  if [ -f "$img" ]; then
    count=$((count + 1))
    echo "[AL-world] [$count/$LIMIT] 分析: $(basename "$img")"
    bash "$AL_WORLD_DIR/scripts/al-analyze.sh" "$img" "$MODEL"

    if [ "$count" -ge "$LIMIT" ]; then
      echo "[AL-world] 已达到批量上限 $LIMIT"
      break
    fi
  fi
done

echo "[AL-world] 批量分析完成，共处理 $count 张图片"