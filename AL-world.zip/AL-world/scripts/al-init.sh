#!/bin/bash
# AL-world 初始化脚本 — 首次部署时交互式配置视觉模型
set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
AL_WORLD_DIR="$(dirname "$SCRIPT_DIR")"
CONFIG_FILE="$AL_WORLD_DIR/services/config.json"

echo "============================================"
echo "  AL-world v3.0 — 首次部署配置向导"
echo "============================================"
echo ""
echo "此skill需要配置一个视觉模型才能发挥自进化功能。"
echo "AL-world会使用视觉模型分析图片 → 提取提示词 → 自动分类 → 更新索引。"
echo ""

# 询问是否配置
echo -n "请问现在配置视觉模型吗？(Y/n): "
read -r setup_now
if [[ "$setup_now" == "n" || "$setup_now" == "N" ]]; then
  echo ""
  echo "您可以在之后随时运行此脚本配置，或手动设置环境变量："
  echo "  export KIMI_API_KEY=\"sk-xxxx\""
  echo "  export STEPFUN_API_KEY=\"sk-xxxx\""
  echo ""
  echo "支持的模型:"
  echo "  1. Kimi (moonshot-v1) — 综合表现均衡"
  echo "  2. StepFun (step-1v) — 对东方艺术理解较好"
  echo "  3. Qwen-VL-Max — 细节描述更细致"
  echo ""
  echo "提示：您可以提供给我kimi多模态模型的api或其它视觉模型的api。"
  exit 0
fi

echo ""
echo "选择要配置的视觉模型:"
echo "  1) Kimi (moonshot-v1) — 推荐，综合表现均衡"
echo "  2) StepFun (step-1v-32k) — 东方艺术理解较好"
echo "  3) Qwen-VL-Max — 细节描述更细致"
echo "  4) 全部配置"
echo ""
echo -n "请选择 (1-4): "
read -r model_choice

case "$model_choice" in
  1) MODELS=("kimi") ;;
  2) MODELS=("stepfun") ;;
  3) MODELS=("qwen") ;;
  4) MODELS=("kimi" "stepfun" "qwen") ;;
  *) MODELS=("kimi") ;;
esac

for model in "${MODELS[@]}"; do
  echo ""
  echo "配置模型: $model"
  echo -n "请输入 $model 的API密钥 (留空跳过): "
  read -r API_KEY

  if [ -z "$API_KEY" ]; then
    echo "跳过 $model"
    continue
  fi

  case "$model" in
    kimi)
      ENV_VAR="KIMI_API_KEY"
      ;;
    stepfun)
      ENV_VAR="STEPFUN_API_KEY"
      ;;
    qwen)
      ENV_VAR="QWEN_API_KEY"
      ;;
  esac

  # 写入当前shell环境
  export "$ENV_VAR=$API_KEY"

  # 尝试写入shell配置文件
  if [ -f "$HOME/.bashrc" ]; then
    if ! grep -q "export $ENV_VAR=" "$HOME/.bashrc" 2>/dev/null; then
      echo "export $ENV_VAR=\"$API_KEY\"" >> "$HOME/.bashrc"
      echo "已添加到 ~/.bashrc"
    fi
  fi
  if [ -f "$HOME/.zshrc" ]; then
    if ! grep -q "export $ENV_VAR=" "$HOME/.zshrc" 2>/dev/null; then
      echo "export $ENV_VAR=\"$API_KEY\"" >> "$HOME/.zshrc"
      echo "已添加到 ~/.zshrc"
    fi
  fi

  # 写入Windows profile
  if [ -f "$HOME/.profile" ]; then
    if ! grep -q "export $ENV_VAR=" "$HOME/.profile" 2>/dev/null; then
      echo "export $ENV_VAR=\"$API_KEY\"" >> "$HOME/.profile"
    fi
  fi

  echo "$model 配置完成"
done

echo ""
echo "============================================"
echo "  初始化完成！请执行以下命令激活"
echo "============================================"
echo ""
echo "  1. 重建向量索引:"
echo "     cd $AL_WORLD_DIR && python services/vector-engine.py rebuild"
echo ""
echo "  2. 测试分析一张图片:"
echo "     bash scripts/al-analyze.sh <图片路径>"
echo ""
echo "  3. 查看系统状态:"
echo "     bash scripts/al-serve.sh"
echo ""
echo "提示：您也可以现在提供给我kimi多模态模型的api或其它视觉模型的api，我会帮您自动配置。"