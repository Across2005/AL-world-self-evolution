#!/bin/bash
# AL-world 单张图片分析入口
# 用法: ./al-analyze.sh <图片路径> [模型]

set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
AL_WORLD_DIR="$(dirname "$SCRIPT_DIR")"
IMAGE="${1:?错误: 请提供图片路径}"
MODEL="${2:-kimi}"

if [ ! -f "$IMAGE" ]; then
  echo "错误: 文件不存在: $IMAGE"
  exit 1
fi

echo "[AL-world] 开始分析: $IMAGE"
echo "[AL-world] 使用模型: $MODEL"

# 1. 视觉模型分析
echo "[AL-world] 步骤1/3: 调用视觉模型 $MODEL..."
RESULT_FILE="$AL_WORLD_DIR/tmp/vision-$(date +%s).json"
node "$AL_WORLD_DIR/services/vision-bridge.js" --image "$IMAGE" --model "$MODEL" > "$RESULT_FILE"

# 2. 知识处理流水线
echo "[AL-world] 步骤2/3: 提取精华提示词..."
python "$AL_WORLD_DIR/services/knowledge-pipeline.py" --input "$RESULT_FILE"

echo "[AL-world] 步骤3/3: 完成"
echo "分析结果: $RESULT_FILE"