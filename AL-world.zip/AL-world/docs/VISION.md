# AL-world 视觉模型集成指南

## 支持的视觉模型

| 模型 | 提供商 | 接入方式 | 费用 |
|------|--------|---------|------|
| moonshot-v1-8k-vision-preview | Kimi (月之暗面) | HTTP API | 按token计费 |
| step-1v-32k | StepFun (阶跃星辰) | HTTP API | 按token计费 |
| qwen-vl-max | Qwen (阿里通义) | HTTP API | 按token计费 |

## 配置

编辑 `services/config.json`，设置相应的API密钥环境变量：

```bash
# Kimi
export KIMI_API_KEY="sk-xxxxxxxxxxxx"

# StepFun
export STEPFUN_API_KEY="sk-xxxxxxxxxxxx"

# Qwen-VL
export QWEN_API_KEY="sk-xxxxxxxxxxxx"
```

## 视觉分析Prompt设计

每次调用视觉模型时，系统会自动附加以下指令（位于 `vision-bridge.js` 的 `buildVisionPrompt` 函数）：

要求模型返回结构化JSON，包含：
- `composition` — 构图分析
- `color_lighting` — 色彩与光照分析
- `style_technique` — 风格与技法分析
- `mood_narrative` — 情绪与叙事分析
- `ai_prompts` — 可直接复用的英/中文生图提示词
- `category_suggestion` — 建议的知识库分类
- `sub_category` — 建议的子类名

## 调用示例

```bash
# 单张分析
node services/vision-bridge.js --image path/to/img.png --model kimi

# 自动分类存储
python services/knowledge-pipeline.py --input tmp/vision-result-xxx.json

# 一键完成
bash scripts/al-analyze.sh path/to/img.png kimi
```

## 模型选择建议

- **Kimi**: 综合表现均衡，适合日常使用
- **StepFun**: 对东方艺术/国风元素理解较好
- **Qwen-VL-Max**: 对画面细节描述更细致，适合高精度分析

## 添加新模型

1. 在 `services/config.json` 的 `models` 中添加模型配置
2. 在 `vision-bridge.js` 中添加对应的API调用函数
3. 在 `scripts/al-analyze.sh` 的模型参数列表中注册

## 故障排除

- `401 Unauthorized`: 检查API密钥是否正确设置
- `rate limit exceeded`: 降低请求频率
- `file not found`: 检查图片路径是否正确