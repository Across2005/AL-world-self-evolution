---
name: AL-world
description: AI绘画增强Skill v3.1 — 自进化向量检索 + 真实Embedding后端 + 质量加权 + 智能分类存储
version: 3.1.0
setup_required: true
setup_script: scripts/al-init.sh
knowledge_base:
  - hanfu-culture: 汉文化服饰元素库（形制/纹样/配色/朝代特征）
  - figure-drawing: 自然人体绘画参考库（解剖/姿态/光照/材质）
  - art-prompts: 泛用绘画提示词库（风格/构图/氛围/参数模板）
features:
  - 向量化语义检索: 自然语言搜索替代关键词匹配
  - 自进化分类: 新分类自动注册到全部索引系统
  - 自进化闭环: 每次保存自动更新同义词表 + 标签索引 + 向量索引
  - 评分反馈: 用户评价提示词质量，倒逼索引优化
  - 视觉模型桥接: 支持 Kimi/StepFun/Qwen-VL
auto_classify: true
vision_models:
  - kimi
  - stepfun
  - qwen-vl
---

# AL-world v3.0 — AI Learning Art World

## 概述

AL-world 是一个**具有自进化能力的AI绘画增强skill**。它基于三大知识库（汉文化服饰、人体绘画、泛用提示词），实现了：

| 功能 | 方向 | 说明 |
|------|------|------|
| 语义向量检索 | 方向一 | 自然语言搜索替代关键词匹配，找到最相关的知识条目 |
| 新建分类自动注册 | 方向二 | 每次新建分类 → 自动更新 category-map + tag-index + vector-index |
| 自进化闭环 | 方向二 | 标签同义词表随新条目自动扩展，不依赖人工维护 |
| 评分反馈 | 方向二 | 用户可对提示词质量打分，高质量条目在检索时权重提升 |
| 真实向量后端 | 方向一 | 可选接入 bge-m3 / text2vec 等 HTTP 推理服务，不可用时自动回退轻量向量 |
| 质量加权检索 | 方向二 | search 时按 `vote_score` 对结果加权（+0.2/-0.2），高评分条目优先命中 |
| 视觉模型桥接 | — | 接入Kimi/StepFun/Qwen分析图片 → 提取提示词 → 自动归类 |

## 首次部署：配置视觉模型

> **重要**：此skill需要配置一个视觉模型才能发挥自进化功能。

运行初始化向导：
```bash
bash scripts/al-init.sh
```

或手动设置环境变量：
```bash
export KIMI_API_KEY="sk-xxxx"
export STEPFUN_API_KEY="sk-xxxx"
```

> 您也可以直接告诉AI agent您的API密钥，agent会帮您自动配置。

## 切换真实向量模型（可选）

默认使用内置轻量级向量（无需任何依赖）。如需更高语义精度，可接入 bge-m3 / text2vec 等本地或远程推理服务：

编辑 `services/config.json`：
```json
"embedding": {
  "provider": "http",
  "endpoint": "http://localhost:8000/v1/embeddings",
  "model": "BAAI/bge-m3",
  "api_key_env": "EMBEDDING_API_KEY",
  "dim": 1024,
  "request_timeout": 10
}
```

- 兼容 OpenAI / FlagEmbedding 风格的返回结构（`data[].embedding` 或 `embeddings[]`）
- 推理服务不可用时**自动回退**到轻量级向量，系统始终可运行
- 切换后端后执行 `python services/vector-engine.py rebuild` 重建索引（向量维度随之更新）

## 质量加权检索

每次用户通过 `--feedback` 打分后，`vote_score` 会同步写入 `vector-index.json`，search 时按如下规则调整排序：

```
final = (vec_sim * 0.7 + tag_sim * 0.3) + 0.2 * clamp(vote_score / 3, -1, 1)
```

高评分条目在生图时被优先召回，低评分条目权重降低——实现自进化闭环的"越用越强"。

## 工作流程（自进化版本）

```
用户输入图片
    ↓
vision-bridge.js (Node.js) → 调用Kimi/StepFun → 结构化视觉分析
    ↓
knowledge-pipeline.py (Python v3.0)
    ├─ 向量检索 → 找出最相似已有条目
    ├─ 标签匹配 → 三路融合打分
    └─ 请示用户 → 保存到匹配/新建/选择分类
    ↓  (用户确认)
保存提示词 → 自动注册到所有索引:
    ├─ category-map.json (新类别映射)
    ├─ tag-index.json (新标签倒排)
    ├─ vector-index.json (新向量条目)
    └─ synonyms.json (新同义词扩展)
    ↓
生图时 → 向量语义搜索 → 自动调用最相关知识
```

## 新建分类自动进化

当用户在分类对话框中选择"新建分类"时，系统会自动执行以下操作：

1. **写入 prompts.json** → 新条目
2. **注册 category-map.json** → 添加 `{kb}-{sub}` 映射
3. **注册 tag-index.json** → 新标签指向新条目
4. **注册 vector-index.json** → 向量化后加入语义搜索库
5. **扩展 synonyms.json** → 新标签加入同义词表

这意味着：**每一次新建分类后，下一次检索立刻就能匹配到这个新分类**。

## 使用方法

### 1. 初始化（首次运行）
```bash
bash scripts/al-init.sh
python services/vector-engine.py rebuild
```

### 2. 分析单张图片
```bash
bash scripts/al-analyze.sh /path/to/image.jpg kimi
```

### 3. 语义搜索知识库
```bash
python services/classify.py search "唐代女子齐胸襦裙金色刺绣"
```

### 4. 重建索引（新增大量数据后）
```bash
python services/vector-engine.py rebuild
```

### 5. 给提示词评分（自进化闭环）
```bash
python services/knowledge-pipeline.py --feedback "hanfu-culture:prompts.json:ming_mamianqun +1"
```

### 6. 系统状态
```bash
python services/vector-engine.py status
```

## 自进化闭环详解

### 保存时触发：

```
save_and_evolve()
  ├─ 写入 prompts.json
  ├─ subprocess → vector-engine.py add-entry
  │   ├─ category-map.json 更新
  │   ├─ tag-index.json 更新
  │   └─ synonyms.json 扩展
  └─ 完成：所有索引一步到位
```

### 评分反馈流：

```
生图结果 → 用户投票 (👍/👎) 
    ↓
knowledge-pipeline.py --feedback
    ├─ 修改 prompts.json 中 vote_score
    └─ quality: high/medium/low
    ↓
下次向量检索时 → 高质量条目权重 +0.2
```

## 文件索引

```
AL-world/
├── SKILL.md                   # 本文件
├── knowledge/                # 三大知识库
│   ├── hanfu-culture/
│   │   ├── index.json        # 类别索引
│   │   └── prompts.json      # 可复用提示词（含 vote_score）
│   ├── figure-drawing/
│   │   ├── index.json
│   │   └── prompts.json
│   └── art-prompts/
│       ├── index.json
│       └── prompts.json
├── services/                  # 核心引擎
│   ├── config.json            # 模型+阈值配置
│   ├── vision-bridge.js       # 视觉模型桥接 (Node.js)
│   ├── vector-engine.py       # 向量检索 + 索引自进化 (v3.0)
│   ├── knowledge-pipeline.py  # 知识流水线 + 自进化闭环 (v3.0)
│   ├── classify.py            # 三路融合分类引擎 (v3.0)
│   └── package.json
├── scripts/
│   ├── al-init.sh             # 首次部署配置向导（含vision提示）
│   ├── al-analyze.sh          # 单张分析
│   ├── al-batch.sh            # 批量分析
│   └── al-serve.sh            # 状态检查
└── index/                     # 全局索引（自进化）
    ├── category-map.json      # 类别映射
    ├── tag-index.json         # 标签倒排索引
    ├── vector-index.json      # 向量索引
    └── synonyms.json         # 自进化同义词表
```