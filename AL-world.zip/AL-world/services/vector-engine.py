#!/usr/bin/env python3
"""
AL-world 向量化检索引擎 (v3.1)
方向一：多模态向量化检索 — 语义Embedding替代纯关键词匹配
方向二：自进化索引 — 新分类自动注册到索引系统
"""

import json
import os
import sys
import re
import ssl
import hashlib
import argparse
import urllib.request
import urllib.error
from pathlib import Path
from datetime import datetime
from difflib import SequenceMatcher
import logging

logging.basicConfig(level=logging.INFO, format='[AL-world] %(levelname)s: %(message)s')
logger = logging.getLogger(__name__)

BASE_DIR = Path(os.path.expanduser("~")) / ".agents" / "skills" / "AL-world"
INDEX_DIR = BASE_DIR / "index"
KNOWLEDGE_DIR = BASE_DIR / "knowledge"
VECTOR_INDEX_PATH = INDEX_DIR / "vector-index.json"
CONFIG_PATH = BASE_DIR / "services" / "config.json"


def load_config():
    try:
        if CONFIG_PATH.exists():
            with open(CONFIG_PATH, 'r', encoding='utf-8') as f:
                return json.load(f)
    except Exception:
        pass
    return {}

# ---------------------------------------------------------------------------
# 轻量级语义Embedding（无需外部模型，基于字面+拼音+近义词+关键词统计）
# 当用户配置了text2vec/bge等模型后，可无缝切换到真实向量库
# ---------------------------------------------------------------------------

class LightweightEmbedding:
    def __init__(self):
        self.dim = 128
        # 内置中英文近义词/同义词扩展表（自进化的种子）
        self.synonym_map = self._build_synonym_map()
        # 前缀词权重
        self.prefix_weights = {
            '汉服': 0.3, '古风': 0.25, '明代': 0.2, '唐代': 0.2, '宋代': 0.2,
            'breast': 0.3, 'pose': 0.25, 'lighting': 0.3, 'style': 0.2,
            '赛博': 0.2, '水墨': 0.2, '仙侠': 0.2, '暗黑': 0.2
        }

    def _build_synonym_map(self):
        # 可动态扩展：新分类的标签自动加入此处
        return {
            '汉服': ['汉服', '汉元素', '汉风', '古风', '国风', '中华服饰', '传统服饰', 'hanfu', 'chinese traditional'],
            '交领右衽': ['右衽', '交领', '左襟右衽', 'y领', 'cross collar', 'right lapel'],
            '马面裙': ['马面', 'mamian', 'horse face skirt', '四裙门'],
            '曲裾': ['曲裾', 'quju', 'curved robe'],
            '唐代': ['唐代', '唐风', '盛唐', 'tang dynasty', '唐制'],
            '明代': ['明代', '明朝', '明制', 'ming dynasty'],
            '宋代': ['宋代', '宋朝', '宋制', 'song dynasty'],
            '魏晋': ['魏晋', '晋制', '六朝', 'wei jin'],
            '云纹': ['云纹', '祥云', 'cloud pattern', '如意云'],
            '龙纹': ['龙纹', '龙', 'dragon', '五爪龙'],
            '宝相花': ['宝相花', 'baoxiang', 'treasure flower'],
            '玄黑': ['玄黑', '玄色', 'black', '墨黑', '玄青'],
            '金色': ['金', 'gold', '金色', '鎏金', '错金', '织金'],
            '红色': ['红', 'red', '朱红', '绛赤', '赤色', '大红'],
            '配色素': ['配色', 'palette', '色彩', 'color scheme', 'chromatic'],
            '胸部': ['胸部', '乳房', 'breast', '胸', 'chest'],
            '姿态': ['pose', '姿态', 'posture', '站姿', '坐姿', '躺姿'],
            '拉伸': ['stretch', '拉伸', '伸展', 'flex', '伸展'],
            '赛博朋克': ['赛博', 'cyberpunk', '霓虹', '科幻街景', '赛博格'],
            '水墨': ['水墨', 'ink wash', '写意', '国画', '墨色'],
            '仙侠': ['仙侠', 'xianxia', '修真', '修仙', '古风仙侠'],
            '明暗对照': ['chiaroscuro', '明暗对照', '戏剧光', '伦勃朗'],
            '中心对称': ['对称', 'symmetric', '中心对称', '中轴对称', '居中'],
            '构图': ['构图', 'composition', '布局', '画面结构', '取景'],
            '光照': ['光照', 'lighting', '光效', '打光', '布光', '照明'],
            '氛围': ['氛围', 'mood', 'atmosphere', '气氛', '情绪'],
            '技法': ['技法', 'technique', '技巧', '手法', '渲染'],
            '赛博古风': ['赛博古风', 'silkpunk', '丝绸朋克', 'cyber hanfu', '赛博国风'],
            '哥特': ['哥特', 'gothic', '暗黑系', '哥特风'],
        }

    def extend_synonyms(self, new_tags):
        """自进化：将新标签加入同义词表"""
        added = 0
        for tag in new_tags:
            if tag not in self.synonym_map:
                self.synonym_map[tag] = [tag]
                added += 1
        return added

    def embed_text(self, text):
        """将文本映射到128维向量（确定性哈希+统计特征）"""
        text = text.lower()
        tokens = re.findall(r'[\w\u4e00-\u9fff]+', text)
        vec = [0.0] * self.dim

        for token in tokens:
            h = hashlib.md5(token.encode('utf-8')).hexdigest()
            seed = int(h[:8], 16)
            for i in range(8):
                idx = (seed + i * 13) % self.dim
                vec[idx] += 1.0
            weight = 1.0
            for prefix, w in self.prefix_weights.items():
                if token.startswith(prefix) or prefix.startswith(token):
                    weight = max(weight, w)
                    break
            vec[seed % self.dim] += weight

        # L2归一化
        norm = sum(x*x for x in vec)**0.5
        if norm > 0:
            vec = [x/norm for x in vec]
        return vec

    def cosine_similarity(self, a, b):
        dot = sum(x*y for x, y in zip(a, b))
        return dot

    def expand_tags(self, tags):
        """同义词扩展"""
        expanded = set()
        for tag in tags:
            tag_lower = tag.lower()
            matched = False
            for key, syns in self.synonym_map.items():
                if tag_lower == key.lower() or tag_lower in [s.lower() for s in syns]:
                    expanded.update(syns)
                    matched = True
                    break
            if not matched:
                expanded.add(tag)
        return list(expanded)


# ---------------------------------------------------------------------------
# 真实向量模型接入（bge-m3 / text2vec 等），通过 HTTP 推理服务调用
# 不可用时自动回退到 LightweightEmbedding，保证系统始终可运行
# ---------------------------------------------------------------------------

class HTTPEmbedding:
    """调用外部 Embedding 推理服务（OpenAI / FlagEmbedding 兼容接口）。"""

    def __init__(self, cfg):
        self.endpoint = (cfg.get("endpoint") or "").strip()
        self.model = cfg.get("model") or ""
        self.api_key = os.environ.get(cfg.get("api_key_env") or "", "") if cfg.get("api_key_env") else ""
        self.dim = int(cfg.get("dim") or 1024)
        self.timeout = int(cfg.get("request_timeout") or 10)
        # 标签扩展/同义词自进化仍复用轻量实现（与向量维度无关）
        self._tag_helper = LightweightEmbedding()
        self._cache = {}
        if not self.endpoint:
            raise ValueError("embedding.endpoint 未配置，无法使用真实向量模型")

    def _http_embed(self, text):
        """返回向量列表或 None（出错时回退）。"""
        body = json.dumps({"model": self.model, "input": text}).encode("utf-8")
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        req = urllib.request.Request(self.endpoint, data=body, headers=headers, method="POST")
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                data = json.loads(resp.read().decode("utf-8"))
            # 兼容多种返回结构
            if isinstance(data, dict):
                if "data" in data and isinstance(data["data"], list):
                    return data["data"][0].get("embedding")
                if "embeddings" in data and isinstance(data["embeddings"], list):
                    return data["embeddings"][0]
            return None
        except (urllib.error.URLError, urllib.error.HTTPError, ssl.SSLError, ValueError, KeyError, IndexError) as e:
            logger.warning(f"真实向量模型调用失败，回退轻量向量: {e}")
            return None

    def embed_text(self, text):
        text = (text or "").strip()
        if text in self._cache:
            return self._cache[text]
        vec = self._http_embed(text)
        if vec is None or len(vec) == 0:
            vec = self._tag_helper.embed_text(text)
        if len(vec) != self.dim:
            # 维度不一致时强制回退到轻量实现，避免破坏余弦相似度
            vec = self._tag_helper.embed_text(text)
        self._cache[text] = vec
        return vec

    def cosine_similarity(self, a, b):
        return sum(x * y for x, y in zip(a, b))

    def expand_tags(self, tags):
        return self._tag_helper.expand_tags(tags)

    def extend_synonyms(self, tags):
        return self._tag_helper.extend_synonyms(tags)


class EmbeddingFactory:
    """根据 config.embedding.provider 选择向量后端。"""

    @staticmethod
    def create(config):
        emb_cfg = (config or {}).get("embedding", {})
        provider = (emb_cfg.get("provider") or "lightweight").lower()
        if provider in ("http", "remote", "bge", "text2vec", "real"):
            try:
                return HTTPEmbedding(emb_cfg)
            except Exception as e:
                logger.warning(f"真实向量模型不可用，回退到轻量级: {e}")
        return LightweightEmbedding()


# ---------------------------------------------------------------------------
# 向量索引管理与检索
# ---------------------------------------------------------------------------

class VectorIndex:
    def __init__(self):
        cfg = load_config()
        self.embed = EmbeddingFactory.create(cfg)
        self.index = self._load()

    def _load(self):
        if VECTOR_INDEX_PATH.exists():
            with open(VECTOR_INDEX_PATH, 'r', encoding='utf-8') as f:
                return json.load(f)
        return {
            "name": "AL-world 向量检索索引",
            "version": "3.0.0",
            "entries": [],
            "dim": self.embed.dim
        }

    def _save(self):
        with open(VECTOR_INDEX_PATH, 'w', encoding='utf-8') as f:
            json.dump(self.index, f, ensure_ascii=False, indent=2)

    def rebuild_all(self):
        """遍历整个知识库重建向量索引（含 vote_score 同步）"""
        self.index["entries"] = []
        self.index["dim"] = self.embed.dim
        for kb_name in ["hanfu-culture", "figure-drawing", "art-prompts"]:
            prompts_path = KNOWLEDGE_DIR / kb_name / "prompts.json"
            if not prompts_path.exists():
                continue
            with open(prompts_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            for pid, prompt in data.get("prompts", {}).items():
                text = prompt.get("en", "") + " " + prompt.get("zh", "") + " " + " ".join(prompt.get("tags", []))
                text += " " + prompt.get("composition", "") + " " + prompt.get("color_lighting", "")
                vec = self.embed.embed_text(text)
                self.index["entries"].append({
                    "id": f"{kb_name}:prompts.json:{pid}",
                    "kb": kb_name,
                    "sub": pid,
                    "vector": vec,
                    "tags": prompt.get("tags", []),
                    "en_preview": prompt.get("en", "")[:100],
                    "vote_score": prompt.get("vote_score", 0)
                })
        self._save()

    def add_entry(self, kb, prompt_id, en_text, zh_text, tags, comp, color):
        """单条增量添加（新建分类时使用），同步 vote_score"""
        # 从 prompts.json 读取已记录的 vote_score
        vote = 0
        prompts_path = KNOWLEDGE_DIR / kb / "prompts.json"
        if prompts_path.exists():
            try:
                with open(prompts_path, 'r', encoding='utf-8') as f:
                    pd = json.load(f)
                vote = pd.get("prompts", {}).get(prompt_id, {}).get("vote_score", 0)
            except Exception:
                pass
        text = en_text + " " + zh_text + " " + " ".join(tags) + " " + comp + " " + color
        vec = self.embed.embed_text(text)
        self.index["entries"].append({
            "id": f"{kb}:prompts.json:{prompt_id}",
            "kb": kb,
            "sub": prompt_id,
            "vector": vec,
            "tags": tags,
            "en_preview": en_text[:100],
            "vote_score": vote
        })
        self._save()

    def search(self, query, top_k=5):
        """语义检索：向量+标签融合打分，并应用 vote_score 质量加权"""
        if not self.index["entries"]:
            return []

        q_vec = self.embed.embed_text(query)
        q_tags = re.findall(r'[\w\u4e00-\u9fff]+', query)
        expanded_tags = self.embed.expand_tags(q_tags)

        scored = []
        for entry in self.index["entries"]:
            vec_sim = self.embed.cosine_similarity(q_vec, entry["vector"])

            tag_sim = 0.0
            if entry["tags"]:
                et_set = set(t.lower() for t in expanded_tags)
                entry_tags = set(t.lower() for t in entry["tags"])
                if et_set and entry_tags:
                    intersect = et_set & entry_tags
                    tag_sim = len(intersect) / max(len(et_set | entry_tags), 1) * 0.5

            combined = vec_sim * 0.7 + tag_sim * 0.3

            # 自进化质量加权：vote_score 归一化到 [-1,1] 后乘以 boost（默认 0.2）
            vote = entry.get("vote_score", 0)
            quality_adj = 0.2 * max(-1.0, min(1.0, vote / 3.0))
            final = combined + quality_adj

            scored.append((final, entry, vote))

        scored.sort(key=lambda x: x[0], reverse=True)
        return [{"score": round(s, 4), "entry": e, "vote_score": v} for s, e, v in scored[:top_k]]


# ---------------------------------------------------------------------------
# 索引自动进化器 — 新分类注册到所有索引
# ---------------------------------------------------------------------------

class IndexEvolver:
    def __init__(self):
        self.embed = LightweightEmbedding()

    def register_new_category(self, kb, sub_category, tags, prompt_id):
        """
        新建分类时，自动注册到所有索引系统：
        1. category-map.json — 添加新映射
        2. tag-index.json — 添加新标签及对应条目
        3. vector-index.json — 添加向量索引项
        """
        # 1. 更新类别映射
        cat_map_path = INDEX_DIR / "category-map.json"
        with open(cat_map_path, 'r', encoding='utf-8') as f:
            cat_map = json.load(f)

        map_key = f"{kb}-{sub}".replace("_", "-")
        if map_key not in cat_map["mappings"]:
            cat_map["mappings"][map_key] = {
                "kb": kb, "sub": sub, "icon": "📁", "auto_generated": True
            }

        # 自动为子类名生成别名
        if sub not in cat_map.get("aliases", {}):
            if "aliases" not in cat_map:
                cat_map["aliases"] = {}
            cat_map["aliases"][sub] = map_key

        with open(cat_map_path, 'w', encoding='utf-8') as f:
            json.dump(cat_map, f, ensure_ascii=False, indent=2)

        # 2. 更新标签索引
        tag_idx_path = INDEX_DIR / "tag-index.json"
        with open(tag_idx_path, 'r', encoding='utf-8') as f:
            tag_idx = json.load(f)

        ref_path = f"{kb}:prompts.json:{prompt_id}"
        for tag in tags:
            if tag not in tag_idx["index"]:
                tag_idx["index"][tag] = []
            if ref_path not in tag_idx["index"][tag]:
                tag_idx["index"][tag].append(ref_path)

        with open(tag_idx_path, 'w', encoding='utf-8') as f:
            json.dump(tag_idx, f, ensure_ascii=False, indent=2)

        # 3. 自进化同义词表
        added = self.embed.extend_synonyms(tags)
        if added > 0:
            # 持久化同义词表到索引目录
            syn_path = INDEX_DIR / "synonyms.json"
            existing = {}
            if syn_path.exists():
                with open(syn_path, 'r', encoding='utf-8') as f:
                    existing = json.load(f)
            existing.update(self.embed.synonym_map)
            saved = 0
            for tag in tags:
                if tag not in existing:
                    existing[tag] = [tag]
                    saved += 1
            if saved > 0:
                with open(syn_path, 'w', encoding='utf-8') as f:
                    json.dump(existing, f, ensure_ascii=False, indent=2)

        print(f"[AL-world] 索引已进化: category-map + tag-index + synonym 已更新")


def main():
    parser = argparse.ArgumentParser(description="AL-world 向量检索+自进化索引引擎")
    parser.add_argument("action", choices=["rebuild", "search", "add-entry", "status"])
    parser.add_argument("--query", "-q", help="检索查询")
    parser.add_argument("--top-k", type=int, default=5)
    parser.add_argument("--kb", help="知识库名")
    parser.add_argument("--sub", help="子类名")
    parser.add_argument("--prompt-id", help="提示词ID")
    parser.add_argument("--tags", nargs="*", help="标签列表")
    parser.add_argument("--en-text", help="英文提示词")
    parser.add_argument("--zh-text", help="中文提示词")
    parser.add_argument("--comp", default="", help="构图描述")
    parser.add_argument("--color", default="", help="色彩描述")
    args = parser.parse_args()

    vindex = VectorIndex()
    evolver = IndexEvolver()

    if args.action == "rebuild":
        print("[AL-world] 完全重建向量索引...")
        vindex.rebuild_all()
        print(f"[AL-world] 索引完成: {len(vindex.index['entries'])} 条向量")

    elif args.action == "search":
        if not args.query:
            print("请提供 --query")
            return
        results = vindex.search(args.query, args.top_k)
        print(f"[AL-world] 语义搜索: {args.query}")
        print(json.dumps(results, ensure_ascii=False, indent=2))

    elif args.action == "add-entry":
        if not all([args.kb, args.prompt_id, args.tags]):
            print("请提供 --kb --prompt-id --tags")
            return
        vindex.add_entry(args.kb, args.prompt_id, args.en_text or "", args.zh_text or "", args.tags, args.comp, args.color)
        evolver.register_new_category(args.kb, args.sub or args.prompt_id, args.tags, args.prompt_id)
        print(f"[AL-world] 条目已添加并注册到所有索引: {args.kb}/{args.prompt_id}")

    elif args.action == "status":
        print(f"[AL-world] 向量索引状态:")
        print(f"  条目数: {len(vindex.index['entries'])}")
        print(f"  维度: {vindex.index.get('dim', '?')}")
        kbs = set(e["kb"] for e in vindex.index["entries"])
        for kb in sorted(kbs):
            count = sum(1 for e in vindex.index["entries"] if e["kb"] == kb)
            print(f"  - {kb}: {count} 条")

if __name__ == "__main__":
    main()