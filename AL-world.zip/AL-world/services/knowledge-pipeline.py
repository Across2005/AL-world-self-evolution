#!/usr/bin/env python3
"""
AL-world Knowledge Pipeline (v3.1)
方向一：向量化检索 + 语义分类
方向二：自进化闭环 — 新分类自动注册所有索引 + 评分反馈
"""

import json
import os
import re
import sys
import argparse
import logging
from pathlib import Path
from datetime import datetime

logging.basicConfig(level=logging.INFO, format='[AL-world] %(levelname)s: %(message)s')
logger = logging.getLogger(__name__)

BASE_DIR = Path(os.path.expanduser("~")) / ".agents" / "skills" / "AL-world"
KNOWLEDGE_DIR = BASE_DIR / "knowledge"
CONFIG_PATH = BASE_DIR / "services" / "config.json"
VECTOR_ENGINE_PATH = BASE_DIR / "services" / "vector-engine.py"
VECTOR_INDEX_PATH = BASE_DIR / "index" / "vector-index.json"


def load_json(path):
    with open(path, 'r', encoding='utf-8') as f:
        return json.load(f)


def save_json(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def load_config():
    return load_json(CONFIG_PATH)


def derive_prompt_id(tags):
    """从标签生成稳定的提示词ID（slug），用于新建条目的唯一键"""
    if not tags:
        return "entry"
    raw = "-".join(str(t) for t in tags[:3])
    slug = re.sub(r'[^a-zA-Z0-9\u4e00-\u9fff-]', '-', raw).strip('-').lower()
    return slug or "entry"


# ---------------------------------------------------------------------------
# 共享分类引擎 — 复用 classify.py 中唯一的 SelfEvolvingClassifier 实现
# （避免与 classify.py 重复维护两套分类逻辑）
# ---------------------------------------------------------------------------

def _load_classifier_class():
    import importlib.util as _ilu
    spec = _ilu.spec_from_file_location(
        "al_classify", str(BASE_DIR / "services" / "classify.py")
    )
    module = _ilu.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.SelfEvolvingClassifier


SelfEvolvingClassifier = _load_classifier_class()


# ---------------------------------------------------------------------------
# 自进化保存器 — 保存后自动注册到所有索引
# ---------------------------------------------------------------------------

class SelfEvolvingSaver:
    def __init__(self):
        self.kb_paths = {
            "hanfu-culture": KNOWLEDGE_DIR / "hanfu-culture" / "prompts.json",
            "figure-drawing": KNOWLEDGE_DIR / "figure-drawing" / "prompts.json",
            "art-prompts": KNOWLEDGE_DIR / "art-prompts" / "prompts.json",
        }

    def save_and_evolve(self, cleaned_data, kb, sub_category, prompt_id=None):
        """保存新知识 + 自动注册到所有索引系统"""
        if kb not in self.kb_paths:
            logger.error(f"未知知识库: {kb}")
            return False

        kb_path = self.kb_paths[kb]
        prompts_data = load_json(kb_path) if kb_path.exists() else {"name": kb, "prompts": {}}

        if prompt_id is None:
            prompt_id = derive_prompt_id(cleaned_data["key_tags"])
        base_pid = prompt_id
        n = 1
        prompts_data.setdefault("prompts", {})
        while prompt_id in prompts_data["prompts"]:
            prompt_id = f"{base_pid}-{n}"
            n += 1

        new_entry = {
            "en": cleaned_data["prompts"].get("en", ""),
            "zh": cleaned_data["prompts"].get("zh", ""),
            "tags": cleaned_data["key_tags"],
            "composition": cleaned_data.get("composition", ""),
            "color_lighting": cleaned_data.get("color_lighting", ""),
            "style_technique": cleaned_data.get("style_technique", ""),
            "mood_narrative": cleaned_data.get("mood_narrative", ""),
            "category": sub_category or "auto-classified",
            "source": "vision-analysis",
            "vote_score": 0,
            "quality": "untracked",
            "timestamp": cleaned_data.get("timestamp", datetime.now().isoformat())
        }

        if "prompts" not in prompts_data:
            prompts_data["prompts"] = {}
        prompts_data["prompts"][prompt_id] = new_entry
        save_json(kb_path, prompts_data)
        logger.info(f"已保存至 {kb}/{prompt_id}")

        # 2. 自进化索引注册：调用 vector-engine.py
        import subprocess
        cmd = [
            sys.executable, str(VECTOR_ENGINE_PATH),
            "add-entry",
            "--kb", kb,
            "--prompt-id", prompt_id,
            "--sub", sub_category or prompt_id,
            "--tags", *cleaned_data["key_tags"],
            "--en-text", cleaned_data["prompts"].get("en", ""),
            "--zh-text", cleaned_data["prompts"].get("zh", ""),
            "--comp", cleaned_data.get("composition", ""),
            "--color", cleaned_data.get("color_lighting", "")
        ]
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
            if result.returncode == 0:
                logger.info(f"所有索引已自动更新")
            else:
                logger.warning(f"索引更新可能有误: {result.stderr[:200]}")
        except Exception as e:
            logger.warning(f"索引更新调用失败: {e}")

        return True

    def record_feedback(self, kb, prompt_id, vote_score):
        """记录用户评分反馈 — 自进化闭环的核心，并同步向量索引权重"""
        for kb_name, path in self.kb_paths.items():
            if not path.exists():
                continue
            data = load_json(path)
            prompts = data.get("prompts", {})
            if prompt_id in prompts:
                new_score = prompts[prompt_id].get("vote_score", 0) + vote_score
                prompts[prompt_id]["vote_score"] = new_score
                prompts[prompt_id]["quality"] = "high" if new_score >= 3 else (
                    "medium" if new_score >= 0 else "low"
                )
                save_json(path, data)
                self._sync_vector_vote(kb_name, prompt_id, new_score)
                logger.info(f"反馈已记录: {kb_name}/{prompt_id} score={new_score}")
                return True
        logger.warning(f"未找到反馈条目: {kb}/{prompt_id}")
        return False

    def _sync_vector_vote(self, kb, prompt_id, vote_score):
        """将投票分数同步进 vector-index.json，使 search 立即生效（无需重建）"""
        try:
            if not VECTOR_INDEX_PATH.exists():
                return
            vi = load_json(VECTOR_INDEX_PATH)
            ref = f"{kb}:prompts.json:{prompt_id}"
            for entry in vi.get("entries", []):
                if entry.get("id") == ref:
                    entry["vote_score"] = vote_score
                    break
            save_json(VECTOR_INDEX_PATH, vi)
        except Exception as e:
            logger.warning(f"向量索引投票同步失败: {e}")


# ---------------------------------------------------------------------------
# 主流程
# ---------------------------------------------------------------------------

def clean_ai_prompts(vision_result):
    """从视觉分析结果中提取精华可复用部分"""
    prompts = vision_result.get("ai_prompts", {})
    return {
        "extracted_from": vision_result.get("category_suggestion", "unknown"),
        "composition": vision_result.get("composition", ""),
        "color_lighting": vision_result.get("color_lighting", ""),
        "style_technique": vision_result.get("style_technique", ""),
        "mood_narrative": vision_result.get("mood_narrative", ""),
        "prompts": prompts,
        "key_tags": prompts.get("key_tags", []),
        "timestamp": datetime.now().isoformat()
    }


def build_interactive_prompt(classifier_result, tags, all_categories):
    lines = [
        "\n" + "=" * 60,
        "AL-world 自进化知识分类系统",
        "=" * 60,
        f"标签: {', '.join(tags)}",
    ]
    if classifier_result["kb"]:
        lines.append(f"自动匹配: {classifier_result['kb']}/{classifier_result['sub']}")
        lines.append(f"置信度: {classifier_result['confidence']:.1%}")
    else:
        lines.append(f"未找到匹配 ({classifier_result.get('reason', '未知')})")

    lines.append("")
    lines.append("选项:")
    lines.append("  1. 保存到匹配分类")
    lines.append("  2. 新建一个分类存储")
    lines.append("  3. 保存到其他已有分类")
    lines.append("  4. 从已有分类列表中选择")
    lines.append("")
    lines.append("  0. 跳过不保存 (或 q 退出)")
    lines.append("")
    lines.append("已有分类:")
    seen_kb = {}
    for c in all_categories[:20]:
        seen_kb[c["kb"]] = seen_kb.get(c["kb"], 0) + 1
    for k, v in seen_kb.items():
        lines.append(f"  - {k}: {v} 条目")
    lines.append(f"  (共 {len(all_categories)} 个条目)")
    return "\n".join(lines)


def get_user_choice():
    try:
        return input("\n请输入选项: ").strip()
    except EOFError:
        return "0"
    except KeyboardInterrupt:
        return "0"


def main():
    parser = argparse.ArgumentParser(description="AL-world 自进化知识流水线 v3.0")
    parser.add_argument("--input", "-i", required=True, help="视觉分析结果JSON文件")
    parser.add_argument("--auto", action="store_true", help="自动模式（跳过用户确认）")
    parser.add_argument("--dry-run", action="store_true", help="仅展示，不保存")
    parser.add_argument("--feedback", help="记录反馈: --feedback kb/prompt_id/+1")
    args = parser.parse_args()

    config = load_config()
    classifier = SelfEvolvingClassifier()
    saver = SelfEvolvingSaver()

    # 反馈模式：--feedback "kb:prompts.json:prompt_id +1"
    if args.feedback:
        parts = args.feedback.split(" ")
        if len(parts) == 2:
            ref_parts = parts[0].split(":")
            score = int(parts[1])
            if len(ref_parts) == 3:
                saver.record_feedback(ref_parts[0], ref_parts[2], score)
        return

    input_path = Path(args.input)
    if not input_path.exists():
        logger.error(f"文件不存在: {args.input}")
        sys.exit(1)

    with open(input_path, 'r', encoding='utf-8') as f:
        vision_result = json.load(f)

    cleaned = clean_ai_prompts(vision_result)
    tags = cleaned["key_tags"]
    en_text = cleaned["prompts"].get("en", "")
    zh_text = cleaned["prompts"].get("zh", "")

    logger.info(f"提取标签: {', '.join(tags) if tags else '无'}")

    cat_result = classifier.classify(tags, en_text, zh_text)
    all_categories = classifier.list_all()

    if args.dry_run:
        print(json.dumps(cleaned, ensure_ascii=False, indent=2))
        print(build_interactive_prompt(cat_result, tags, all_categories))
        return

    if args.auto:
        if cat_result["kb"] and cat_result["confidence"] >= config.get("classify_threshold", 0.5):
            saver.save_and_evolve(cleaned, cat_result["kb"], cat_result.get("sub") or "auto-classified", derive_prompt_id(tags))
            logger.info("自动保存完成（自进化索引已更新）")
        else:
            saver.save_and_evolve(cleaned, "art-prompts", "auto-" + datetime.now().strftime("%Y%m%d"), derive_prompt_id(tags))
            logger.info("保存到 art-prompts/auto（自进化索引已更新）")
        return

    print(build_interactive_prompt(cat_result, tags, all_categories))
    choice = get_user_choice()

    if choice in ("0", "q"):
        logger.info("已跳过")

    elif choice == "1":
        if cat_result["kb"]:
            sub = input(f"  确认子类 [{cat_result['sub']}]: ").strip() or cat_result.get("sub") or "auto-classified"
            saver.save_and_evolve(cleaned, cat_result["kb"], sub, derive_prompt_id(tags))
        else:
            new_kb = input("  输入知识库名: ").strip()
            new_sub = input("  输入子类名: ").strip()
            saver.save_and_evolve(cleaned, new_kb, new_sub, derive_prompt_id(tags))

    elif choice == "2":
        new_kb = input("  新建知识库名: ").strip()
        new_sub = input("  新建子类名: ").strip()
        saver.save_and_evolve(cleaned, new_kb, new_sub, derive_prompt_id(tags))

    elif choice == "3":
        print("可选知识库: hanfu-culture, figure-drawing, art-prompts")
        target_kb = input("  目标知识库: ").strip()
        target_sub = input("  子类名: ").strip()
        saver.save_and_evolve(cleaned, target_kb, target_sub, derive_prompt_id(tags))

    elif choice == "4":
        print("\n  所有已有条目:")
        for c in all_categories[:30]:
            print(f"    {c['ref']}")
        ref = input("  输入完整ref路径 (如 hanfu-culture:prompts.json:xxx): ").strip()
        parts = ref.split(":", 2)
        if len(parts) >= 3:
            saver.save_and_evolve(cleaned, parts[0], parts[2], parts[2])
        elif len(parts) == 2:
            saver.save_and_evolve(cleaned, parts[0], parts[1], derive_prompt_id(tags))

    else:
        logger.warning(f"无效选项: {choice}")

    logger.info("处理完成")


if __name__ == "__main__":
    main()