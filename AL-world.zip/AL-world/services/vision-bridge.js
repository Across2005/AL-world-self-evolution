const fs = require('fs');
const path = require('path');
const https = require('https');

const config = JSON.parse(fs.readFileSync(path.join(__dirname, 'config.json'), 'utf-8'));

const args = process.argv.slice(2);
const parsed = {};
for (let i = 0; i < args.length; i++) {
  if (args[i].startsWith('--')) {
    const key = args[i].slice(2);
    parsed[key] = args[i + 1] && !args[i + 1].startsWith('--') ? args[i + 1] : true;
    if (parsed[key] !== true) i++;
  }
}

const IMAGE_PATH = parsed.image || parsed.i;
const MODEL = parsed.model || 'kimi';

function imageToBase64(filePath) {
  const data = fs.readFileSync(filePath);
  const ext = path.extname(filePath).toLowerCase();
  const mimeMap = { '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp', '.gif': 'image/gif' };
  const mime = mimeMap[ext] || 'image/jpeg';
  return `data:${mime};base64,${data.toString('base64')}`;
}

function buildVisionPrompt() {
  return `请从绘画学习的角度分析这张图片，严格按照以下JSON格式返回（不要有任何其他文字）：
{
  "composition": "构图分析（类型、视角、空间布局）",
  "color_lighting": "色彩与光照分析（主色调、光源方向、对比特征）",
  "style_technique": "风格与技法分析（流派、绘制技法、材质表现）",
  "mood_narrative": "情绪与叙事分析（氛围、故事感、视觉焦点）",
  "ai_prompts": {
    "en": "可直接用于AI生图的英文提示词（包含姿态/服饰/光照/氛围等参数）",
    "zh": "可直接用于AI生图的中文提示词",
    "key_tags": ["标签1", "标签2"]
  },
  "category_suggestion": "建议存入的知识库分类（hanfu-culture/figure-drawing/art-prompts或new）",
  "sub_category": "建议的子类名称"
}`;
}

function parseModelContent(rawContent) {
  try {
    const jsonMatch = rawContent.match(/\{[\s\S]*\}/);
    return JSON.parse(jsonMatch ? jsonMatch[0] : rawContent);
  } catch (e) {
    return null;
  }
}

function callVisionModel(base64Image, modelName) {
  return new Promise((resolve, reject) => {
    const modelConfig = config.models[modelName];
    if (!modelConfig) return reject(new Error(`不支持的模型: ${modelName}`));

    const apiKey = process.env[modelConfig.api_key_env];
    if (!apiKey) return reject(new Error(`请设置环境变量 ${modelConfig.api_key_env}`));

    const messages = [
      { role: 'system', content: '你是专业的绘画分析助手，擅长从构图、色彩、风格、技法、情绪等维度分析图片，并提取可直接用于AI生图的提示词。' },
      { role: 'user', content: [{ type: 'image_url', image_url: { url: base64Image } }, { type: 'text', text: buildVisionPrompt() }] }
    ];

    const payload = JSON.stringify({
      model: modelConfig.model,
      messages,
      max_tokens: modelConfig.max_tokens,
      temperature: 0.3,
      response_format: { type: 'json_object' }
    });

    const req = https.request({
      hostname: new URL(modelConfig.endpoint).hostname,
      path: new URL(modelConfig.endpoint).pathname,
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${apiKey}`, 'Content-Length': Buffer.byteLength(payload) }
    }, res => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try {
          const parsed = JSON.parse(data);
          const content = parsed.choices?.[0]?.message?.content || '{}';
          const result = parseModelContent(content);
          if (!result) throw new Error(`无法解析模型返回: ${content.slice(0, 500)}`);
          resolve(result);
        } catch (e) { reject(new Error(`${modelName}解析失败: ${e.message}\n原始响应: ${data.slice(0, 500)}`)); }
      });
    });
    req.on('error', reject);
    req.write(payload);
    req.end();
  });
}

async function analyze() {
  if (!IMAGE_PATH) {
    console.error('用法: node vision-bridge.js --image <图片路径> --model kimi|stepfun|qwen');
    process.exit(1);
  }
  if (!fs.existsSync(IMAGE_PATH)) {
    console.error(`文件不存在: ${IMAGE_PATH}`);
    process.exit(1);
  }

  console.error(`[AL-world] 分析图片: ${IMAGE_PATH}`);
  console.error(`[AL-world] 使用模型: ${MODEL}`);

  const base64 = imageToBase64(IMAGE_PATH);

  const result = await callVisionModel(base64, MODEL);

  const outputPath = path.join(config.tmp_path, `vision-result-${Date.now()}.json`);
  fs.writeFileSync(outputPath, JSON.stringify(result, null, 2));
  console.error(`[AL-world] 分析完成，结果已保存: ${outputPath}`);
  // 仅将 JSON 输出到 stdout，便于管道/重定向直接 json.load
  console.log(JSON.stringify(result, null, 2));
}

analyze().catch(err => {
  console.error(`[AL-world] 错误: ${err.message}`);
  process.exit(1);
});