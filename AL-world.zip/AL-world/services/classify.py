#!/usr/bin/env python3
"""
AL-world 自进化分类引擎 (v3.1)
方向一：向量化语义检索 + 标签融合分类
方向二：自动接纳新分类到所有索引
"""

import json
import sys
import os
import importlib.util
from pathlib import Path
from difflib import SequenceMatcher

BASE_DIR = Path(os.path.expanduser("~")) / ".agents" / "skills" / "AL-world"
INDEX_DIR = BASE_DIR / "index"
KNOWLEDGE_DIR = BASE_DIR / "knowledge"

# 引入向量引擎（使用完整路径避免Python模块名不支持连字符）
_vector_engine_path = os.path.join(str(BASE_DIR / "services"), "vector-engine.py")
spec = importlib.util.spec_from_file_location("vector_engine", _vector_engine_path)
ve = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ve)
VectorIndex = ve.VectorIndex
IndexEvolver = ve.IndexEvolver


class SelfEvolvingClassifier:
    def __init__(self):
        self.vector_index = VectorIndex()
        self.evolver = IndexEvolver()
        self.tag_index = self._load_json(INDEX_DIR / "tag-index.json", {})
        self.cat_map = self._load_json(INDEX_DIR / "category-map.json", {})

    def _load_json(self, path, fallback):
        try:
            if path.exists():
                with open(path, 'r', encoding='utf-8') as f:
                    return json.load(f)
        except:
            pass
        return fallback

    def classify(self, tags, en_text="", zh_text="", top_k=5):
        """
        二路融合分类：
        1. 向量语义检索（优先）
        2. 标签精确/模糊匹配（补充）
        """
        query = " ".join(tags) + " " + en_text[:300] + " " + zh_text[:300]
        vector_results = self.vector_index.search(query, top_k)

        tag_idx = self.tag_index.get("index", {})

        # 融合打分
        combined = {}

        for vr in vector_results:
            ref = vr["entry"]["id"]
            combined[ref] = combined.get(ref, 0) + vr["score"] * 0.6

        for tag in tags:
            for indexed_tag, refs in tag_idx.items():
                tag_lower = tag.lower()
                indexed_lower = indexed_tag.lower()

                if tag_lower == indexed_lower:
                    weight = 0.4
                elif tag_lower in indexed_lower or indexed_lower in tag_lower:
                    weight = 0.2
                else:
                    ratio = SequenceMatcher(None, tag_lower, indexed_lower).ratio()
                    if ratio > 0.5:
                        weight = ratio * 0.2
                    else:
                        continue

                for ref in (refs if isinstance(refs, list) else [refs]):
                    combined[ref] = combined.get(ref, 0) + weight

        if not combined:
            return {"kb": None, "sub": None, "confidence": 0.0, "vector_matches": vector_results[:3]}

        best_ref = max(combined, key=combined.get)
        best_score = min(combined[best_ref] / max(len(tags) * 0.8, 0.5), 1.0)
        parts = best_ref.split(":", 2)
        kb = parts[0] if len(parts) > 0 else None
        mid = parts[1] if len(parts) > 1 else None
        leaf = parts[2] if len(parts) > 2 else None
        # ref 格式: kb:prompts.json:prompt_id 或 kb:category:entry(*)
        # 真实条目的可定位 id 是 leaf；通配/容器名则回退到 mid（类别）
        sub = leaf if (mid == "prompts.json" and leaf and not leaf.endswith("*")) else mid

        return {
            "kb": kb,
            "sub": sub,
            "confidence": round(best_score, 4),
            "reason": best_ref,
            "vector_matches": vector_results[:3]
        }

    def list_all(self):
        """列出所有可用的分类条目"""
        seen = set()
        items = []
        tag_idx = self.tag_index.get("index", {})
        for refs in tag_idx.values():
            for r in (refs if isinstance(refs, list) else [refs]):
                if r not in seen:
                    seen.add(r)
                    p = r.split(":", 2)
                    items.append({"ref": r, "kb": p[0] if len(p) > 0 else "?", "sub": p[1] if len(p) > 1 else "?"})
        # 也加上向量索引中的条目
        for e in self.vector_index.index.get("entries", []):
            if e["id"] not in seen:
                seen.add(e["id"])
                items.append({"ref": e["id"], "kb": e.get("kb", "?"), "sub": e.get("sub", "?")})
        return items

    def rebuild_indexes(self):
        """完全重建向量索引"""
        print("[AL-world] 重建向量索引...")
        self.vector_index.rebuild_all()
        print("[AL-world] 所有索引重建完成")


if __name__ == "__main__":
    clf = SelfEvolvingClassifier()

    if len(sys.argv) > 1:
        if sys.argv[1] == "list":
            for item in clf.list_all():
                print(f"  {item['ref']}")

        elif sys.argv[1] == "rebuild":
            clf.rebuild_indexes()

        elif sys.argv[1] == "search":
            query = " ".join(sys.argv[2:]) if len(sys.argv) > 2 else ""
            if not query:
                query = input("输入搜索词: ")
            results = clf.vector_index.search(query)
            for r in results:
                print(f"  [{r['score']:.3f}] {r['entry']['id']}")
                print(f"    {r['entry']['en_preview']}")

        elif sys.argv[1] == "classify":
            input_path = sys.argv[2] if len(sys.argv) > 2 else None
            if input_path and Path(input_path).exists():
                with open(input_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                tags = data.get("ai_prompts", {}).get("key_tags", [])
                en = data.get("ai_prompts", {}).get("en", "")
                zh = data.get("ai_prompts", {}).get("zh", "")
                result = clf.classify(tags, en, zh)
                print(json.dumps(result, ensure_ascii=False, indent=2))
            else:
                print("请提供视觉分析结果JSON路径")

        else:
            print("用法: python classify.py [list|rebuild|search|classify <文件>]")
    else:
        # 交互式搜索
        while True:
            try:
                q = input("\nAL-world 分类引擎 > ").strip()
                if not q or q in ("exit", "quit", "q"):
                    break
                if q == "rebuild":
                    clf.rebuild_indexes()
                elif q == "list":
                    for item in clf.list_all():
                        print(f"  {item['ref']}")
                else:
                    results = clf.vector_index.search(q)
                    for r in results:
                        print(f"  [{r['score']:.3f}] {r['entry']['id']}")
                        print(f"    {r['entry']['en_preview']}")
            except (EOFError, KeyboardInterrupt):
                break